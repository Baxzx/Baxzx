export type AppConfig = {
  app_id: string;
};
