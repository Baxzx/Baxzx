# @worldcoin/create-mini-app

## 0.4.0

### Minor Changes

- b239460: fix npx auth secret

## 0.3.0

### Minor Changes

- 5248854: allow asking for auth from the get go

## 0.2.0

### Minor Changes

- 35ba818: improvements
