/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: ['static.usernames.app-backend.toolsforhumanity.com'],
  },
};

export default nextConfig;
