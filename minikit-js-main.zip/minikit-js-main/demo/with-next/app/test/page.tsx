import { SearchParams } from '@/components/ClientContent/SearchParams';

export default function TestPage() {
  return (
    <div className="bg-white text-black min-h-full p-5">
      <SearchParams />
    </div>
  );
}
